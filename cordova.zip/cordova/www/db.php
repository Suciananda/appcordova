<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id15157624_akdmk","trhY]WO)Dj|9x+O5","id15157624_akademik") or die ("could not connect database");
?>